CREATE TABLE "Seg_hist" (  
    cpf int, 
    dt_sefmento        DATE,
    gerente VARCHAR (255),
    segmento VARCHAR (255)
    
    );

CREATE TABLE "Posicao_hist" (  
    cpf int, 
    dt_posicao        DATE
    );
 