INSERT INTO "Seg_hist"
    VALUES(
        1,
        '2016-09-04',
        'Marcos',
        'B'
            ),
    (
        1,
        '2016-10-04',
        'Raquel',
        'W'
    ),
    (   2,
        '2016-11-04',
        'Raquel',
        'W'
            ),
    (   3,
        '2016-09-04',
        'Marcos',
        'W'
            );

INSERT INTO "Posicao_hist"
    VALUES(
        1,
        '2016-10-03'
            ),
    (   
        2,
        '2016-10-04'
    ),
    (   3,
        '2016-10-05'
    );